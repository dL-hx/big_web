const zIndices = {
  hide: -1,
  auto: 'auto',
  base: 0,
};

export default zIndices;
