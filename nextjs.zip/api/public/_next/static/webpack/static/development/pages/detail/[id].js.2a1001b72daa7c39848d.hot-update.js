webpackHotUpdate("static/development/pages/detail/[id].js",{

/***/ "./axiosConfig.js":
false,

/***/ "./node_modules/axios/index.js":
false,

/***/ "./node_modules/axios/lib/adapters/xhr.js":
false,

/***/ "./node_modules/axios/lib/axios.js":
false,

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
false,

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
false,

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
false,

/***/ "./node_modules/axios/lib/core/Axios.js":
false,

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
false,

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
false,

/***/ "./node_modules/axios/lib/core/createError.js":
false,

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
false,

/***/ "./node_modules/axios/lib/core/enhanceError.js":
false,

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
false,

/***/ "./node_modules/axios/lib/core/settle.js":
false,

/***/ "./node_modules/axios/lib/core/transformData.js":
false,

/***/ "./node_modules/axios/lib/defaults.js":
false,

/***/ "./node_modules/axios/lib/helpers/bind.js":
false,

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
false,

/***/ "./node_modules/axios/lib/helpers/cookies.js":
false,

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
false,

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
false,

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
false,

/***/ "./node_modules/axios/lib/helpers/spread.js":
false,

/***/ "./node_modules/axios/lib/utils.js":
false,

/***/ "./pages/detail/[id].js":
/*!******************************!*\
  !*** ./pages/detail/[id].js ***!
  \******************************/
/*! exports provided: __N_SSG, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"__N_SSG\", function() { return __N_SSG; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"default\", function() { return Detail; });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"./node_modules/react/index.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/Layout */ \"./components/Layout.js\");\n/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @chakra-ui/core */ \"./node_modules/@chakra-ui/core/dist/esm/index.js\");\n/* harmony import */ var _emotion_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/core */ \"./node_modules/@emotion/core/dist/core.browser.esm.js\");\nvar _jsxFileName = \"/Users/administrators/Desktop/\\u62C9\\u94A9/React\\u8FDB\\u9636\\u4E0E\\u5B9E\\u6218\\uFF08\\u4E09\\uFF09/9-Next/code/movie/pages/detail/[id].js\";\n\nvar __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;\n\nfunction _EMOTION_STRINGIFIED_CSS_ERROR__() { return \"You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop).\"; }\n\n\n\n\n\nvar DetailContainer = false ? undefined : {\n  name: \"17sfcu0-DetailContainer\",\n  styles: \"padding:10px 0;& > p{font-size:14px;margin-bottom:10px;}& > img{margin-bottom:10px;display:block;};label:DetailContainer;\",\n  map: \"/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hZG1pbmlzdHJhdG9ycy9EZXNrdG9wL+aLiemSqS9SZWFjdOi/m+mYtuS4juWunuaImO+8iOS4ie+8iS85LU5leHQvY29kZS9tb3ZpZS9wYWdlcy9kZXRhaWwvW2lkXS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFNMkIiLCJmaWxlIjoiL1VzZXJzL2FkbWluaXN0cmF0b3JzL0Rlc2t0b3Av5ouJ6ZKpL1JlYWN06L+b6Zi25LiO5a6e5oiY77yI5LiJ77yJLzktTmV4dC9jb2RlL21vdmllL3BhZ2VzL2RldGFpbC9baWRdLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExheW91dCBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9MYXlvdXRcIjtcbmltcG9ydCB7IEJveCwgSGVhZGluZywgRGl2aWRlciwgVGV4dCB9IGZyb20gXCJAY2hha3JhLXVpL2NvcmVcIjtcbmltcG9ydCB7IGNzcyB9IGZyb20gJ0BlbW90aW9uL2NvcmUnO1xuaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJztcbmltcG9ydCB7IGJhc2VVUkwgfSBmcm9tICcuLi8uLi9heGlvc0NvbmZpZyc7XG5cbmNvbnN0IERldGFpbENvbnRhaW5lciA9IGNzc2BcbiAgcGFkZGluZzogMTBweCAwO1xuICAmID4gcCB7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIH1cbiAgJiA+IGltZyB7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgfVxuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGV0YWlsKCkge1xuICByZXR1cm4gKFxuICAgIDxMYXlvdXQ+XG4gICAgICA8Qm94IG1heFc9ezEyMDB9IG14PVwiYXV0b1wiIG10PVwiNzBweFwiPlxuICAgICAgICA8SGVhZGluZyBhcz1cImgyXCIgc2l6ZT1cInhsXCI+XG4gICAgICAgICAgTWFydmVsIE1pc3Npb24gUmVjYXA6IENhcHRhaW4gTWFydmVs4oCZcyBTdGFyIG9mIEhhbGFcbiAgICAgICAgPC9IZWFkaW5nPlxuICAgICAgICA8SGVhZGluZ1xuICAgICAgICAgIG10PVwiMTBweFwiXG4gICAgICAgICAgYXM9XCJoNFwiXG4gICAgICAgICAgc2l6ZT1cImxnXCJcbiAgICAgICAgICBjb2xvcj1cImdyYXkuNTAwXCJcbiAgICAgICAgICBmb250V2VpZ2h0PVwibGlnaHRcIlxuICAgICAgICA+XG4gICAgICAgICAgVGhlIHJlc3VsdHMgYXJlIG91dCBvZiB0aGlzIHdvcmxkIVxuICAgICAgICA8L0hlYWRpbmc+XG4gICAgICAgIDxEaXZpZGVyIG10PVwiMTBweFwiIC8+XG4gICAgICAgIDxCb3ggb3ZlcmZsb3c9XCJoaWRkZW5cIiBtdD1cIjEwcHhcIj5cbiAgICAgICAgICA8VGV4dCBmbG9hdD1cImxlZnRcIj7kvZzogIU6IFRvbWFzPC9UZXh0PlxuICAgICAgICAgIDxUZXh0IGZsb2F0PVwicmlnaHRcIj7lj5HluIPml7bpl7Q6IDIwNDUtMDUtMjU8L1RleHQ+XG4gICAgICAgIDwvQm94PlxuICAgICAgICA8RGl2aWRlciBtdD1cIjEwcHhcIiAvPlxuICAgICAgICA8Qm94IGNzcz17RGV0YWlsQ29udGFpbmVyfT5cbiAgICAgICAgICA8cD5cbiAgICAgICAgICAgIENvbmdyYXRzIGFnZW50cyDigJQgaXQgYXBwZWFycyB0aGF0IG1hbnkgb2YgeW91IHN1Y2Nlc3NmdWxseSBjb21wbGV0ZWRcbiAgICAgICAgICAgIHRoZSBsYXRlc3QgTWFydmVsIE1pc3Npb24hXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgQ29uZ3JhdHMgYWdlbnRzIOKAlCBpdCBhcHBlYXJzIHRoYXQgbWFueSBvZiB5b3Ugc3VjY2Vzc2Z1bGx5IGNvbXBsZXRlZFxuICAgICAgICAgICAgdGhlIGxhdGVzdCBNYXJ2ZWwgTWlzc2lvbiFcbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBDb25ncmF0cyBhZ2VudHMg4oCUIGl0IGFwcGVhcnMgdGhhdCBtYW55IG9mIHlvdSBzdWNjZXNzZnVsbHkgY29tcGxldGVkXG4gICAgICAgICAgICB0aGUgbGF0ZXN0IE1hcnZlbCBNaXNzaW9uIVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cbiAgICA8L0xheW91dD5cbiAgKTtcbn1cblxuLy8g6I635Y+W55So5oi35Y+v5Lul6K6/6Zeu5Yiw55qE5omA5pyJ55qE6Lev55Sx5Y+C5pWwXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUGF0aHMgKCkge1xuICBsZXQgeyBkYXRhIH0gPSBhd2FpdCBheGlvcy5nZXQoJy9hcGkvdmlkZW9zJywge2Jhc2VVUkx9KTtcbiAgY29uc29sZS5sb2coZGF0YSk7XG4gIGxldCBwYXRocyA9IGRhdGEubWFwKGlkID0+ICh7cGFyYW1zOiB7aWR9fSkpXG4gIHJldHVybiB7XG4gICAgcGF0aHMsXG4gICAgZmFsbGJhY2s6IGZhbHNlXG4gIH1cbn1cblxuLy8g5qC55o2u6Lev55Sx5Y+C5pWw6I635Y+W5YW25a+55bqU55qE5pWw5o2uXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUHJvcHMoKSB7XG5cbn1cbiJdfQ== */\",\n  toString: _EMOTION_STRINGIFIED_CSS_ERROR__\n};\nvar __N_SSG = true;\nfunction Detail() {\n  return Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_components_Layout__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 21,\n      columnNumber: 5\n    }\n  }, Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Box\"], {\n    maxW: 1200,\n    mx: \"auto\",\n    mt: \"70px\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 22,\n      columnNumber: 7\n    }\n  }, Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Heading\"], {\n    as: \"h2\",\n    size: \"xl\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 23,\n      columnNumber: 9\n    }\n  }, \"Marvel Mission Recap: Captain Marvel\\u2019s Star of Hala\"), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Heading\"], {\n    mt: \"10px\",\n    as: \"h4\",\n    size: \"lg\",\n    color: \"gray.500\",\n    fontWeight: \"light\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 26,\n      columnNumber: 9\n    }\n  }, \"The results are out of this world!\"), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Divider\"], {\n    mt: \"10px\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 35,\n      columnNumber: 9\n    }\n  }), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Box\"], {\n    overflow: \"hidden\",\n    mt: \"10px\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 36,\n      columnNumber: 9\n    }\n  }, Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Text\"], {\n    \"float\": \"left\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 37,\n      columnNumber: 11\n    }\n  }, \"\\u4F5C\\u8005: Tomas\"), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Text\"], {\n    \"float\": \"right\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 38,\n      columnNumber: 11\n    }\n  }, \"\\u53D1\\u5E03\\u65F6\\u95F4: 2045-05-25\")), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Divider\"], {\n    mt: \"10px\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 40,\n      columnNumber: 9\n    }\n  }), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"Box\"], {\n    css: DetailContainer,\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 41,\n      columnNumber: 9\n    }\n  }, Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(\"p\", {\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 42,\n      columnNumber: 11\n    }\n  }, \"Congrats agents \\u2014 it appears that many of you successfully completed the latest Marvel Mission!\"), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(\"p\", {\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 46,\n      columnNumber: 11\n    }\n  }, \"Congrats agents \\u2014 it appears that many of you successfully completed the latest Marvel Mission!\"), Object(_emotion_core__WEBPACK_IMPORTED_MODULE_3__[\"jsx\"])(\"p\", {\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 50,\n      columnNumber: 11\n    }\n  }, \"Congrats agents \\u2014 it appears that many of you successfully completed the latest Marvel Mission!\"))));\n} // 获取用户可以访问到的所有的路由参数\n\n_c = Detail;\n\nvar _c;\n\n$RefreshReg$(_c, \"Detail\");\n\n;\n    var _a, _b;\n    // Legacy CSS implementations will `eval` browser code in a Node.js context\n    // to extract CSS. For backwards compatibility, we need to check we're in a\n    // browser context before continuing.\n    if (typeof self !== 'undefined' &&\n        // AMP / No-JS mode does not inject these helpers:\n        '$RefreshHelpers$' in self) {\n        var currentExports_1 = module.__proto__.exports;\n        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;\n        // This cannot happen in MainTemplate because the exports mismatch between\n        // templating and execution.\n        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports_1, module.i);\n        // A module can be accepted automatically based on its exports, e.g. when\n        // it is a Refresh Boundary.\n        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports_1)) {\n            // Save the previous exports on update so we can compare the boundary\n            // signatures.\n            module.hot.dispose(function (data) {\n                data.prevExports = currentExports_1;\n            });\n            // Unconditionally accept an update to this module, we'll check if it's\n            // still a Refresh Boundary later.\n            module.hot.accept();\n            // This field is set when the previous version of this module was a\n            // Refresh Boundary, letting us know we need to check for invalidation or\n            // enqueue an update.\n            if (prevExports !== null) {\n                // A boundary can become ineligible if its exports are incompatible\n                // with the previous exports.\n                //\n                // For example, if you add/remove/change exports, we'll want to\n                // re-execute the importing modules, and force those components to\n                // re-render. Similarly, if you convert a class component to a\n                // function, we want to invalidate the boundary.\n                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports_1)) {\n                    module.hot.invalidate();\n                }\n                else {\n                    self.$RefreshHelpers$.scheduleUpdate();\n                }\n            }\n        }\n        else {\n            // Since we just executed the code for the module, it's possible that the\n            // new exports made it ineligible for being a boundary.\n            // We only care about the case when we were _previously_ a boundary,\n            // because we already accepted this update (accidental side effect).\n            var isNoLongerABoundary = prevExports !== null;\n            if (isNoLongerABoundary) {\n                module.hot.invalidate();\n            }\n        }\n    }\n\n/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ \"./node_modules/webpack/buildin/harmony-module.js\")(module)))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9kZXRhaWwvLmpzPzk1NGQiXSwibmFtZXMiOlsiRGV0YWlsQ29udGFpbmVyIiwiRGV0YWlsIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7QUFJQSxJQUFNQSxlQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxDQUFyQjs7QUFZZSxTQUFTQyxNQUFULEdBQWtCO0FBQy9CLFNBQ0UsMERBQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLDBEQUFDLG1EQUFEO0FBQUssUUFBSSxFQUFFLElBQVg7QUFBaUIsTUFBRSxFQUFDLE1BQXBCO0FBQTJCLE1BQUUsRUFBQyxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsMERBQUMsdURBQUQ7QUFBUyxNQUFFLEVBQUMsSUFBWjtBQUFpQixRQUFJLEVBQUMsSUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnRUFERixFQUlFLDBEQUFDLHVEQUFEO0FBQ0UsTUFBRSxFQUFDLE1BREw7QUFFRSxNQUFFLEVBQUMsSUFGTDtBQUdFLFFBQUksRUFBQyxJQUhQO0FBSUUsU0FBSyxFQUFDLFVBSlI7QUFLRSxjQUFVLEVBQUMsT0FMYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUpGLEVBYUUsMERBQUMsdURBQUQ7QUFBUyxNQUFFLEVBQUMsTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBYkYsRUFjRSwwREFBQyxtREFBRDtBQUFLLFlBQVEsRUFBQyxRQUFkO0FBQXVCLE1BQUUsRUFBQyxNQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsMERBQUMsb0RBQUQ7QUFBTSxhQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixFQUVFLDBEQUFDLG9EQUFEO0FBQU0sYUFBTSxPQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNENBRkYsQ0FkRixFQWtCRSwwREFBQyx1REFBRDtBQUFTLE1BQUUsRUFBQyxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFsQkYsRUFtQkUsMERBQUMsbURBQUQ7QUFBSyxPQUFHLEVBQUVELGVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEdBREYsRUFLRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRHQUxGLEVBU0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0R0FURixDQW5CRixDQURGLENBREY7QUFzQ0QsQyxDQUVEOztLQXpDd0JDLE0iLCJmaWxlIjoiLi9wYWdlcy9kZXRhaWwvW2lkXS5qcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMYXlvdXQgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvTGF5b3V0XCI7XG5pbXBvcnQgeyBCb3gsIEhlYWRpbmcsIERpdmlkZXIsIFRleHQgfSBmcm9tIFwiQGNoYWtyYS11aS9jb3JlXCI7XG5pbXBvcnQgeyBjc3MgfSBmcm9tICdAZW1vdGlvbi9jb3JlJztcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XG5pbXBvcnQgeyBiYXNlVVJMIH0gZnJvbSAnLi4vLi4vYXhpb3NDb25maWcnO1xuXG5jb25zdCBEZXRhaWxDb250YWluZXIgPSBjc3NgXG4gIHBhZGRpbmc6IDEwcHggMDtcbiAgJiA+IHAge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICB9XG4gICYgPiBpbWcge1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gIH1cbmA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERldGFpbCgpIHtcbiAgcmV0dXJuIChcbiAgICA8TGF5b3V0PlxuICAgICAgPEJveCBtYXhXPXsxMjAwfSBteD1cImF1dG9cIiBtdD1cIjcwcHhcIj5cbiAgICAgICAgPEhlYWRpbmcgYXM9XCJoMlwiIHNpemU9XCJ4bFwiPlxuICAgICAgICAgIE1hcnZlbCBNaXNzaW9uIFJlY2FwOiBDYXB0YWluIE1hcnZlbOKAmXMgU3RhciBvZiBIYWxhXG4gICAgICAgIDwvSGVhZGluZz5cbiAgICAgICAgPEhlYWRpbmdcbiAgICAgICAgICBtdD1cIjEwcHhcIlxuICAgICAgICAgIGFzPVwiaDRcIlxuICAgICAgICAgIHNpemU9XCJsZ1wiXG4gICAgICAgICAgY29sb3I9XCJncmF5LjUwMFwiXG4gICAgICAgICAgZm9udFdlaWdodD1cImxpZ2h0XCJcbiAgICAgICAgPlxuICAgICAgICAgIFRoZSByZXN1bHRzIGFyZSBvdXQgb2YgdGhpcyB3b3JsZCFcbiAgICAgICAgPC9IZWFkaW5nPlxuICAgICAgICA8RGl2aWRlciBtdD1cIjEwcHhcIiAvPlxuICAgICAgICA8Qm94IG92ZXJmbG93PVwiaGlkZGVuXCIgbXQ9XCIxMHB4XCI+XG4gICAgICAgICAgPFRleHQgZmxvYXQ9XCJsZWZ0XCI+5L2c6ICFOiBUb21hczwvVGV4dD5cbiAgICAgICAgICA8VGV4dCBmbG9hdD1cInJpZ2h0XCI+5Y+R5biD5pe26Ze0OiAyMDQ1LTA1LTI1PC9UZXh0PlxuICAgICAgICA8L0JveD5cbiAgICAgICAgPERpdmlkZXIgbXQ9XCIxMHB4XCIgLz5cbiAgICAgICAgPEJveCBjc3M9e0RldGFpbENvbnRhaW5lcn0+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBDb25ncmF0cyBhZ2VudHMg4oCUIGl0IGFwcGVhcnMgdGhhdCBtYW55IG9mIHlvdSBzdWNjZXNzZnVsbHkgY29tcGxldGVkXG4gICAgICAgICAgICB0aGUgbGF0ZXN0IE1hcnZlbCBNaXNzaW9uIVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8cD5cbiAgICAgICAgICAgIENvbmdyYXRzIGFnZW50cyDigJQgaXQgYXBwZWFycyB0aGF0IG1hbnkgb2YgeW91IHN1Y2Nlc3NmdWxseSBjb21wbGV0ZWRcbiAgICAgICAgICAgIHRoZSBsYXRlc3QgTWFydmVsIE1pc3Npb24hXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgQ29uZ3JhdHMgYWdlbnRzIOKAlCBpdCBhcHBlYXJzIHRoYXQgbWFueSBvZiB5b3Ugc3VjY2Vzc2Z1bGx5IGNvbXBsZXRlZFxuICAgICAgICAgICAgdGhlIGxhdGVzdCBNYXJ2ZWwgTWlzc2lvbiFcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvQm94PlxuICAgICAgPC9Cb3g+XG4gICAgPC9MYXlvdXQ+XG4gICk7XG59XG5cbi8vIOiOt+WPlueUqOaIt+WPr+S7peiuv+mXruWIsOeahOaJgOacieeahOi3r+eUseWPguaVsFxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRpY1BhdGhzICgpIHtcbiAgbGV0IHsgZGF0YSB9ID0gYXdhaXQgYXhpb3MuZ2V0KCcvYXBpL3ZpZGVvcycsIHtiYXNlVVJMfSk7XG4gIGNvbnNvbGUubG9nKGRhdGEpO1xuICBsZXQgcGF0aHMgPSBkYXRhLm1hcChpZCA9PiAoe3BhcmFtczoge2lkfX0pKVxuICByZXR1cm4ge1xuICAgIHBhdGhzLFxuICAgIGZhbGxiYWNrOiBmYWxzZVxuICB9XG59XG5cbi8vIOagueaNrui3r+eUseWPguaVsOiOt+WPluWFtuWvueW6lOeahOaVsOaNrlxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRpY1Byb3BzKCkge1xuXG59XG4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/detail/[id].js\n");

/***/ })

})