export default {
    message: 'this is dynamic data'
}