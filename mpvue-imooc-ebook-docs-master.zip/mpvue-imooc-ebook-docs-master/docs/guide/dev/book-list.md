# 图书列表

复用 SearchTable 组件，详见[搜索开发](http://www.youbaobao.xyz/mpvue-docs/guide/dev/search.html)
