# 分类列表

复用 HomeBook 组件，详见[首页开发](http://www.youbaobao.xyz/mpvue-docs/guide/dev/home.html)
