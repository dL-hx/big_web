# mpvue多端小程序开发指南

::: tip
本章节内容为课程配套的文字版本，方便各位同学不便查看视频时使用
:::

<a :href="require('./images/knowledge.png')" target="_blank">![knowledge](./images/knowledge.png)</a>
