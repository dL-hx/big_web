import Icon from './icon'

export default Icon