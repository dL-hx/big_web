export interface IThemeProps {
    [key:string]: {color:string; background:string}
}