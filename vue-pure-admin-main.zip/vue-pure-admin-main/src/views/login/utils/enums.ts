const operates = [
  {
    title: "手机登录"
  },
  {
    title: "二维码登录"
  },
  {
    title: "注册"
  }
];

const thirdParty = [
  {
    title: "微信",
    icon: "wechat"
  },
  {
    title: "支付宝",
    icon: "alipay"
  },
  {
    title: "QQ",
    icon: "qq"
  },
  {
    title: "微博",
    icon: "weibo"
  }
];

export { operates, thirdParty };
