import reSelector from "./src";
import { withInstall } from "/@/utils";

/** 选择器组件 */
export const ReSelector = withInstall(reSelector);

export default ReSelector;
