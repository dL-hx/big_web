import { withInstall } from "/@/utils";
import reSeamlessScroll from "./src/index.vue";

/** 无缝滚动组件 */
export const ReSeamlessScroll = withInstall(reSeamlessScroll);

export default ReSeamlessScroll;
