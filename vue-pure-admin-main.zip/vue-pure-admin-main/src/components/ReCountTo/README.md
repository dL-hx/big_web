normal 普通数字动画组件  
rebound 回弹式数字动画组件
