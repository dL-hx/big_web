import epTableProBar from "./src/bar";
import { withInstall } from "/@/utils";

/** table-crud组件 */
export const EpTableProBar = withInstall(epTableProBar);
