import reFlop from "./src/index.vue";
import { withInstall } from "/@/utils";

/** 时间翻牌组件 */
export const ReFlop = withInstall(reFlop);

export default ReFlop;
