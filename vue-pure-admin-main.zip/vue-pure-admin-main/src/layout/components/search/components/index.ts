import SearchModal from "./SearchModal.vue";

export { SearchModal };
