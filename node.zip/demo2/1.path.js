const path = require('path')
console.log(__filename);

// 1. 获取路径中的基础名称
/* 
1 返回接收路径中的最后一部分
2 第二个参数表示扩展名, 如果没有设置则返回完整文件名称带后缀

*/
console.log(path.basename(__filename));

console.log(path.basename(__filename, '.js'));

console.log(path.basename(__filename, '.css'));

console.log(path.basename('/a/b/c'));
console.log(path.basename('/a/b/c/'));

// 2. 获取路径目录名 (路径)
/* 
1 返回路径中最后一个部分上一层目录所在路径
*/
console.log(path.dirname(__filename));


// 3.获取路径扩展名
/* 
1 返回路径文件中相应文件的后缀名
*/
console.log(path.extname(__filename));

// 4. 解析路径

const obj = path.parse('/a/b/c')
console.log(obj);

// 5. 序列化路径
const obj1 = path.parse('/a/b/c')
console.log(path.format(obj1));

// 6. 是否为绝对路径
// path.isAbsolute('/foo')

// 7. 拼接路径
console.log(path.join('a/b', 'c','index.html'));//=>a\b\c\index.html
console.log(path.join('')); // => .

// 8.规范化路径
console.log(path.normalize('a///b/c')); // => a\b\c

// 9. 绝对路径
console.log(path.resolve('index.html'));


