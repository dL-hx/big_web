const b1 = Buffer.alloc(10)
const b2 = Buffer.allocUnsafe(10)

console.log(b1);
console.log(b2);


// from 
const b3 = Buffer.from('1')
console.log(b3);

const b4 = Buffer.from('中','utf-8')

console.log(b4.toString())