const fs = require('fs')
const path = require('path')


// console.log(path.resolve(__dirname,'data.txt')); // 找到文件的绝对路径进行拼接

// readFile
// fs.readFile(path.resolve(__dirname,'data.txt'), 'utf-8', (err, data)=>{
//     if(err){
//         return;
//     }

//     console.log(data);

// })


// writeFile
// fs.writeFile(path.resolve(__dirname, 'demo.txt'), 'hello nodejs ', (err) => {
//     if (!err) {
//         // 将写入数据进行读取
//         fs.readFile(path.resolve(__dirname, 'demo.txt'), 'utf-8', (err, data) => {
//             if (err) {
//                 return;
//             }

//             console.log(data);

//         })

//     }
// })


// appendFile
fs.appendFile(path.resolve(__dirname, 'demo.txt'), 'tffans', (err) => {
        if (!err) {
            console.log('写入成功');
            
    
        }
})


// copyFile
fs.copyFile(path.resolve(__dirname, 'demo.txt'),path.resolve(__dirname, 'test.txt'), (err) => {
    if (!err) {
        console.log('拷贝成功');
    }
})

// watchFile 监控文件
// 20s 监控一次
// watchFile 通过定时轮询文件，检查文件是否发生变化
// 第二个参数如果是对象，则代表配置选项
//   interval 表示轮询文件的时间间隔 默认 `5007`
// 回调函数接收 current 和 previous 两个<fs.Stats>类 分别包含文件变化前后的相关信息
fs.watchFile('data.txt', { interval: 20 }, (current, previous) => {
    if (current.mtime !== previous.mtime) {
      // mtime 表示最新修改时间
      console.log('文件内容被修改')
    }
  })


// 调用 API 修改文件
// 也可以手动打开文件去修改内容
fs.writeFile('data.txt', 'Hello', err => {
    console.log('写入内容')
    setTimeout(() => {
      fs.writeFile('data.txt', 'Hello', err => {
        console.log('写入内容相同')
      })
    }, 1000)
  })
  
  // 写入内容
  // 文件内容被修改
  // 写入内容相同
  // 文件内容被修改
  
  // watchFile 监听任务会一直持续，控制台不会退出
  // 需要手动停止监听，当删除了所有监听器，程序就会停止运行
  // 第二个参数可以指定要删除的监听器(watchFile 的回调函数)，如果不指定则删除指定文件的全部监听器
  setTimeout(() => {
    fs.unwatchFile('data.txt')
  }, 3000)
  