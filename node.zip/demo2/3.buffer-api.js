let buf = Buffer.alloc(6)

//fill
// buf.fill('123')
// console.log(buf);
// console.log(buf.toString());

//write
console.log(buf.write('123'));

// toString

// slice

// indexOf  ===-1 不存在

// concat--------拼接buffer

// Buffer.concat([b1,b2])

// isBuffer------是否为Buffer类型
// Buffer.isBuffer(b1)

// 重写方法
ArrayBuffer.prototype.slice = function (sep) {
    
}