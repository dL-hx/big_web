<template>
    <div>
        <h1>Member</h1>
    </div>
</template>

<script>
export default {
name: "Member"
}
</script>

<style scoped>

</style>