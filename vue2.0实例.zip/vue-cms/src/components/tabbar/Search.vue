<template>
    <div>
        <h1>Search</h1>
    </div>
</template>

<script>
export default {
name: "Search"
}
</script>

<style scoped>

</style>