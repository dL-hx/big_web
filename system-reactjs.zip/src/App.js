import * as React from "react"

export default function App() {
    return <div>Hello systemjs</div>
}