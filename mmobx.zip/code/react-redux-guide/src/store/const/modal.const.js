
export const SHOW_MODAL= "showModal"
export const HIDE_MODAL= "hideModal"

export const SHOW_MODAL_ASYNC= "showModalAsync"